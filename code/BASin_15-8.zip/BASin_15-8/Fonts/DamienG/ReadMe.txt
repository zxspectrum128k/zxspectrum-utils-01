These fonts are available for all BASIN users to use in their own applications and may be redistributed as part of those productions.

A credit would be nice, but is not a requirement for redistribution.

All of the fonts provided are standard 768-byte Spectrum fonts and they all represent the full Spectrum character set.

All of the fonts are brand new fresh creations apart from those listed in the "converted" folder that have been recreated from screenshots elsewhere with any missing characters created in the same style.

Have fun and check out new fonts at my site,

[)amien
Damien Guard
http://www.damieng.com/